<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Audience\\Providers\\AudienceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Audience\\Providers\\AudienceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);