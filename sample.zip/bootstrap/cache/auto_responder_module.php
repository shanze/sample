<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AutoResponder\\Providers\\AutoResponderServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AutoResponder\\Providers\\AutoResponderServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);