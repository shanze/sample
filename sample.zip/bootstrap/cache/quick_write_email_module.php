<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\QuickWriteEmail\\Providers\\QuickWriteEmailServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\QuickWriteEmail\\Providers\\QuickWriteEmailServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);