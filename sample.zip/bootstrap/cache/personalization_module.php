<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Personalization\\Providers\\PersonalizationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Personalization\\Providers\\PersonalizationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);