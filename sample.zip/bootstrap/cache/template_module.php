<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Template\\Providers\\TemplateServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Template\\Providers\\TemplateServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);