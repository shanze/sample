<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SenderDomains\\Providers\\SenderDomainsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SenderDomains\\Providers\\SenderDomainsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);