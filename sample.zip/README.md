##### For double-optin settings we have 3 entry points, please make changes to all 3.
1. Add customer by manual add
   ```{
    file: CustomerEntity
    function: addCustomer()
2. Add customer by Form Subscription
   ```{
   file: FormEntity
   function: subscribeViaForm()
3. Add customer by CSV
   ```{
      file: ImportCustomersCSV Job
      function: handle()
      repo: worker
