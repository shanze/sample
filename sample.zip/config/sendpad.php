<?php

return [
    /*
    |--------------------------------------------------------------------------
    | marketing Configurations
    |--------------------------------------------------------------------------
    |
    */
    'worker_url' => env('WORKER_URL'),
    'listener_url' => env('LISTENER_URL'),
    'app_url' => env('APP_URL'),

];
