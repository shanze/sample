<?php

// config for Dietercoopman/Mailspfchecker
return [

];
