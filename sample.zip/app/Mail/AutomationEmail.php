<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;


class AutomationEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($subject,$preHeader,$senderProfile,$content,$model_id)
    {
        $this->subject = $subject;
        $this->pre_header = $preHeader;
        $this->sender_profile = $senderProfile;
        $this->content = $content;
        $this->model_id = $model_id;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $model_id = $this->model_id;
        return $this->subject($this->subject)->from($this->sender_profile)
            ->view('Emails.AutomationEmail')->with([
                'pre_header' => $this->pre_header,
                'content' => $this->content,
            ])->withSwiftMessage(function ($message) use ($model_id){
                $message->getHeaders()->addTextHeader(
                    'X-Model-ID',$model_id
                );
            });;
    }
}
