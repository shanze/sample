<?php

namespace App\Listeners;

use Illuminate\Mail\Events\MessageSending;
use Swift_Mime_IdGenerator;

class MessageSendingListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  \Illuminate\Mail\Events\MessageSending  $event
     * @return void
     */
    public function handle(MessageSending $event)
    {
        $event->message->setId((new Swift_Mime_IdGenerator(config('mail.domain')))->generateId());
    }
}
