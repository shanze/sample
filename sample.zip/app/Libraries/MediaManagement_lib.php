<?php
namespace App\Libraries;


class MediaManagement_lib
{

    protected $media_abs_path;
    protected $template_folder_path;
    protected $media_url;

    public function __construct()
    {
        $this->media_abs_path = '/var/www/userdata/media-data';
        //$this->media_abs_path = env('MEDIA_UPLOADER_ABSOLUTE_PATH');
        $this->template_folder_path = env('GLOBAL_TEMPLATE_FOLDER_PATH');
        $this->media_url = env('MEDIA_URL');
    }

    public function createPageMediaFolder($page_slug){

        $page_media_folder = "{$this->media_abs_path}/{$page_slug}";

        if (!file_exists("{$page_media_folder}")) {
            mkdir("{$page_media_folder}", 0777, true);
        }else{
            dd('exist');
        }
    }

    public function copyImagesToFolder($src, $dst) {
        $dir = opendir($src);
        // Loop through the files in source directory
        while( $file = readdir($dir) ) {
            if (( $file != '.' ) && ( $file != '..' )) {
                if ( is_dir($src . '/' . $file) )
                {
                    // Recursively calling custom copy function
                    // for sub directory
                    custom_copy($src . '/' . $file, $dst . '/' . $file);
                }
                else {
                    copy($src . '/' . $file, $dst . '/' . $file);
                }
            }
        }
        closedir($dir);
    }

    public function createThumbnail($thumbnail_data){

        self::delete_old_thumbnail($thumbnail_data);

        $curl_url = env('THUMBNAIL_CREATOR_SERVICE_URL').'/thumbnail/create?'.http_build_query($thumbnail_data);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $curl_url,
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_TIMEOUT_MS  => 3000
        ));
        $response = curl_exec($curl);
        curl_close($curl);
//        dd($response);
    }

    public function delete_media($page_slug){

        $base_path = $this->media_abs_path;
        $folder_path = "{$base_path}/{$page_slug}";

        if (file_exists("{$folder_path}")) {
            $files = scandir($folder_path);
            if(!empty($files)){
                $hideName = array('.','..','.DS_Store');
                /* While this to there no more files are */
                foreach($files as $filename) {
                    if(!in_array($filename, $hideName)){
                        unlink("{$folder_path}/$filename");
                    }
                }
                rmdir($folder_path);
            }
        }
    }

    public function getImageUrl($data){
        return $this->media_url."{$data['folder_name']}={$data['account_name']}/{$data['page_id']}&imgfile={$data['page_thumbnail']}&v={$data['updated_at']}";
    }

    protected function delete_old_thumbnail($page_data){
        $path_to_page_folder = $this->media_abs_path."/{$page_data['account_name']}/{$page_data['page_id']}";
        $thumbnail_image_path = $path_to_page_folder."/{$page_data['thumbnail']}";
        // first check if page thumbnail is created
        if (file_exists($thumbnail_image_path)){
            unlink($thumbnail_image_path);
        }
    }

    public function createCacheMediaFolder($account_name){
        $cache_media_folder = env('MEDIA_UPLOADER_CACHE_ABSOLUTE_PATH')."/{$account_name}";
        if (!file_exists("{$cache_media_folder}")) {
            mkdir("{$cache_media_folder}", 0777, true);
        }
    }

    static function createConfigFile($data){

        $public_url = 'http://'.$data['host'];
        if(!empty(env('IS_SSL'))){
            $public_url = 'https://'.$data['host'];
        }
        $structureDir = env('CONFIG_STRUCTURE_DIR_PATH');
        $configDir = env('CONFIG_DIR_PATH');
        $structure_file =  $structureDir.'/config.json';
        $configFile = @file_get_contents($structure_file);
        $configFile = str_ireplace([
            '{HOST}',
            '{ACCOUNT_ID}',
            '{ACCOUNT_NAME}',
            '{ACCOUNT_PUBLIC_URL}'
        ], [
            $data['host'],
            $data['account_id'],
            $data['account_name'],
            $public_url

        ], $configFile);
        @file_put_contents("{$configDir}/{$data['host']}.json", $configFile);


    }
}
