<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Cache;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class CustomThrottleMiddleware
{
    public function handle(Request $request, Closure $next, $maxRequests = 300, $decayMinutes = 1)
    {
        $key = 'throttle:' . $request->ip();
        if (Cache::has($key)) {
            if (Cache::get($key) >= $maxRequests) {
                return response()->json(['error' => 'Too Many Attempts. Please try again later.'], 429);
            }
            Cache::increment($key);
        } else {
            Cache::put($key, 1, now()->addMinutes($decayMinutes));
        }

        return $next($request);
    }
}
