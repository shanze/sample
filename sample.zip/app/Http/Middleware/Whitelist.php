<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;

class Whitelist
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $cartzyHost = null;

        if(!empty($request->header('MYCARTZY_HOST'))){
            $cartzyHost = $request->header('MYCARTZY_HOST');
        }

        if(empty($cartzyHost)){
            $cartzyHost = $request->header('X-MYCARTZY-HOST');
        }
//
//         Log::info("All headers: ");
//         Log::info($request->header());

        $whitelist = config('domain-whitelist');

//         Log::info("Whitelisted domain: ");
//         Log::info($whitelist['cartzy']);

        if(!empty($cartzyHost) && !empty($whitelist['cartzy']) && $whitelist['cartzy'] == $cartzyHost){
            return $next($request);
        }else{
            $response['_metadata'] = [
                'outcome' => "NO_ACCESS",
                'outcomeCode' => "403",
                'numOfRecords' => 0,
                'message' => "Access Denied",
            ];
            $response['is_valid'] = false;
            $response['records'] = [];
            $response['errors'] = ["Access Denied"];
            return response()->json($response);
        }
    }
}
