<?php

namespace App\Http\Middleware;

use App\Traits\GlobalResponseTrait;
use App\Traits\UserAccess;
use Closure;

use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Http\Middleware\BaseMiddleware;

class CheckAuth extends BaseMiddleware
{
    use GlobalResponseTrait;
    use UserAccess;
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle($request, Closure $next)
    {
        try {
           $this->authenticate($request);
        }catch (\Exception $e){
            return response($this->helpError(401,'Invalid Token',$e->getMessage()));
        }
        return $next($request);
    }
}
