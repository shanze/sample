<?php

namespace App\Rules;


use Illuminate\Contracts\Validation\Rule;
use Egulias\EmailValidator\EmailLexer;
use Egulias\EmailValidator\Validation\RFCValidation as EmailValidatorRFCValidation;


class CustomEmail implements Rule
{
    public function passes($attribute, $value)
    {
        $emailLexer = new EmailLexer();
        $validator = new EmailValidatorRFCValidation($emailLexer);
        return $validator->isValid($value, $emailLexer);
    }

    public function message()
    {
        return 'The :attribute must be a valid email address.';
    }
}
