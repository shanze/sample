<?php

use App\Models\User;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Modules\Audience\Entities\CustomerEntity;
use Modules\Audience\Entities\Models\Customer;
use Modules\Payments\Entities\CouponCode;
use Modules\Payments\Entities\Models\Plan;
use Modules\Payments\Entities\Models\PlanHistory;
use Modules\Payments\Entities\Models\Subscription;
use Modules\Payments\Entities\Models\UserPlan;
use Modules\Payments\Entities\SpCcDiscount;
use Modules\Payments\Entities\SpCcDiscountTier;


/**
 * @param $reason
 * @param $message
 * @return array
 */
function make_error_object($reason, $message)
{
    //return ['map' => $reason, 'message' => $message];
    return $message;
}

/**
 * @param $messageBagArray
 * @return array
 */
function convert_laravel_input_errors($messageBagArray)
{
    $errors = [];
    foreach ($messageBagArray as $key => $message) {
        $errors[] = make_error_object($key, $message[0]);
    }
    return $errors;
}

/**
 *
 * convert standard error to extension error
 *
 * @param $errors
 * @return array
 */
function convert_laravel_input_errors_to_extension_errors($errors)
{
    return ['error' => $errors[0]['message']];
}

function k_arrayIndexCheck($array, $index)
{
    $value = false;

    if (isset($array[$index]) && $array[$index] != '') {
        $value = $array[$index];
    }
    return $value;
}

function messageTimeFormat($timestamp)
{
    $strTime = strtotime($timestamp); // '2017-05-15 11:29:54'

    $time = time() - $strTime; // to get the time since that moment
    $time = ($time < 1) ? 1 : $time;

    $tokens = array(
        31536000 => 'year',
        2592000 => 'month',
        604800 => 'week',
        172800 => 'one day ago',
        86400 => 'day',
        3600 => 'hour',
        60 => 'minute',
        1 => 'second'
    );

    if ($time <= 86400) {
        $messageTime = 'Today ' . date('g:i A', $strTime);
    } else if ($time > 86400 && $time <= 172800) {
        $messageTime = 'yesterday ' . date('g:i A', $strTime);
    } else {
        $messageTime = date('M j, Y g:i A', $strTime);
    }

    return $messageTime;
}

function stringEncodeForAPI($name)
{
    $name = str_replace("&", "%26", $name);


    return $name;
}

function bulk_insert($table, $data)
{
    $SQLQuery = '';
    $SQLCols = array();

    $queriesArray = [];

    $columnsCount = -1;
    $previousSQLCols = [];


    foreach ($data as $dataRow) {

        $SQLCols = array_keys($dataRow);

        if ($columnsCount != count($SQLCols)) {
            if ($columnsCount != -1) {
                $SQLQuery = rtrim($SQLQuery, ',');
                $SQLQuery .= " ON DUPLICATE KEY UPDATE \n";
                $OnDuplicateSet = array();
                foreach ($previousSQLCols as $Column) {
                    $OnDuplicateSet[] = "`{$Column}`=VALUES(`{$Column}`)";
                }
                $SQLQuery .= implode(", \n", $OnDuplicateSet) . ";";
                $queriesArray[] = $SQLQuery;
            }
            $columnsCount = count($SQLCols);
            $previousSQLCols = $SQLCols;
            $SQLQuery = 'INSERT INTO `' . $table . '`(' . implode(",", $SQLCols) . ') VALUES ';
        }
        $vals = [];
        foreach ($dataRow as $key => $value) {
            $vals[] = $value ? DB::getPdo()->quote((string)$value) : "NULL";
        }
        $SQLValue = '(' . implode(',', $vals) . ')';
        $SQLQuery .= "" . $SQLValue . ",";

    }

    $SQLQuery = rtrim($SQLQuery, ',');


    $SQLQuery .= " ON DUPLICATE KEY UPDATE \n";
    $OnDuplicateSet = array();
    foreach ($SQLCols as $Column) {
        $OnDuplicateSet[] = "`{$Column}`=VALUES(`{$Column}`)";
    }
    $SQLQuery .= implode(", \n", $OnDuplicateSet) . ";";
    $queriesArray[] = $SQLQuery;


//    DB::enableQueryLog();

    $isLastInserted = 0;

    foreach ($queriesArray as $query) {
        DB::insert(ltrim($query, ";"));

        /**
         * This id keep track what if any new record inserted in a table.
         */
        $isLastInserted = DB::getPdo()->lastInsertId();
    }

    return $isLastInserted;
//    print_r(DB::getQueryLog());exit;
}

function urlDomainChecker($url)
{
    $code = 200;
    $status = 'unknown';


    if (preg_match('/http:\/\/(www\.)*vimeo\.com\/.*/', $url)) {
        // do vimeo stuff
        $status = 'vimeo';
    } else if (
        preg_match(
            '/^((?:https?:)?\/\/)?((?:www|m)\.)?((?:youtube\.com|youtu.be))(\/(?:[\w\-]+\?v=|embed\/|v\/)?)([\w\-]+)(\S+)?$/',
            $url)
    ) {
        // do YouTube stuff
        $status = 'youtube';
    } else {
        $code = '403';
    }

    $statusData = [
        'code' => $code,
        'status' => $status,
    ];

    return $statusData;

}

function reformatText($string, $name)
{
    if (empty($name)) {
        return str_replace(' <first_name>', ucfirst($name), $string);
    }

    return str_replace('<first_name>', ucfirst($name), $string);
}

function getUrlDomain($url)
{
    $parseUrl = parse_url(trim($url));

    if (!empty($parseUrl['host'])) {
        $url = 'http://' . $parseUrl['host'];
    } else if (!empty($parseUrl['path'])) {
        $url = 'http://' . $parseUrl['path'];
    }

    return str_ireplace('www.', '', parse_url($url, PHP_URL_HOST));
}

function phonFormatter($phone)
{
    $formatToReplace = array("+", " ", "-", "(", ")");
    $replaceFormat = array("", "", "", "", "");

    return str_replace($formatToReplace, $replaceFormat, $phone);
}

/**
 * Get time according to given timezone.
 *
 * @param $timeZone
 * @param $timeStamp
 * @return false|string
 */
function utcZoneTime($timeZone, $timeStamp)
{
    if ($timeZone) {
        $timeZone = str_replace('GMT', '', $timeZone);

//        $zone = explode(" ",$timeZone);
//        $timeZone = $zone[1];

        $time = strtotime($timeStamp); // get unix time stamp of given timestamp

        return gmdate("Y-m-j H:i:s", $time + 3600 * ($timeZone + date("I")));
    }

    return $timeStamp;
}

function getIndexedvalue($array, $index)
{
    return !empty($array[$index]) ? $array[$index] : NULL;
}

function usaStates()
{
    return array(
        'AL' => 'Alabama',
        'AK' => 'Alaska',
        'AZ' => 'Arizona',
        'AR' => 'Arkansas',
        'CA' => 'California',
        'CO' => 'Colorado',
        'CT' => 'Connecticut',
        'DE' => 'Delaware',
        'DC' => 'District Of Columbia',
        'FL' => 'Florida',
        'GA' => 'Georgia',
        'HI' => 'Hawaii',
        'ID' => 'Idaho',
        'IL' => 'Illinois',
        'IN' => 'Indiana',
        'IA' => 'Iowa',
        'KS' => 'Kansas',
        'KY' => 'Kentucky',
        'LA' => 'Louisiana',
        'ME' => 'Maine',
        'MD' => 'Maryland',
        'MA' => 'Massachusetts',
        'MI' => 'Michigan',
        'MN' => 'Minnesota',
        'MS' => 'Mississippi',
        'MO' => 'Missouri',
        'MT' => 'Montana',
        'NE' => 'Nebraska',
        'NV' => 'Nevada',
        'NH' => 'New Hampshire',
        'NJ' => 'New Jersey',
        'NM' => 'New Mexico',
        'NY' => 'New York',
        'NC' => 'North Carolina',
        'ND' => 'North Dakota',
        'OH' => 'Ohio',
        'OK' => 'Oklahoma',
        'OR' => 'Oregon',
        'PA' => 'Pennsylvania',
        'RI' => 'Rhode Island',
        'SC' => 'South Carolina',
        'SD' => 'South Dakota',
        'TN' => 'Tennessee',
        'TX' => 'Texas',
        'UT' => 'Utah',
        'VT' => 'Vermont',
        'VA' => 'Virginia',
        'WA' => 'Washington',
        'WV' => 'West Virginia',
        'WI' => 'Wisconsin',
        'WY' => 'Wyoming',
    );
}


function AgoFormatConvertInDateFormat($string)
{
    $stringArray = explode(" ", $string);
    $number = $stringArray[0];
    if (isset($stringArray[1])) {
        $str = $stringArray[1];
    } else { // this is yelp case because yelp no having second index
        $str = $string;
    }

    if ($number == 'a') {
        $number = "1";
    }


    if ($str == 'second' || $str == 'Second' || $str == 'seconds' || $str == 'Seconds') {
        $currentDate = Carbon::now();
        $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    } else if ($str == 'minute' || $str == 'Minute' || $str == 'minutes' || $str == 'Minutes') {
        $currentDate = Carbon::now();
        $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    } else if ($str == 'hour' || $str == 'Hour' || $str == 'hours' || $str == 'Hours') {
        $currentDate = Carbon::now();
        $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    } else if ($str == 'today' || $str == 'Today') {
        $currentDate = Carbon::now();
        $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    } else if ($str == 'yesterday' || $str == 'Yesterday') {
        $currentDate = Carbon::now()->subDays(1);
        $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    } else if ($str == 'Days' || $str == 'days' || $str == 'Day' || $str == 'Days') {
        $currentDate = Carbon::now()->subDays($number);
        $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    } else if ($str == 'Week' || $str == 'week' || $str == 'Weeks' || $str == 'weeks') {
        $currentDate = Carbon::now()->subWeek($number);
        $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    } else if ($str == 'Month' || $str == 'month' || $str == 'Months' || $str == 'months') {
        $currentDate = Carbon::now()->subMonth($number);
        $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    } else if ($str == 'year' || $str == 'Year' || $str == 'years' || $str == 'Years') {
        $currentDate = Carbon::now()->subYear($number);
        $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    } else if ($string == 'in the last day') {
        $currentDate = Carbon::now()->subDays(1);
        $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    } //special cases for Google places
    else if ($string == 'in the last week') {
        $currentDate = Carbon::now()->subWeek(1);
        $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');

    } else if ($string == 'just now' || $string == 'Just now' || $string == 'just Now') {
        $currentDate = Carbon::now();
        $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');

    } else if ($string == 'in the last month') {
        $currentDate = Carbon::now()->subMonth(1);
        $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');

    } else if ($string == 'in the last year') {
        $currentDate = Carbon::now()->subYear(1);
        $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');

    } else {

        $string = explode(' ', $string); // this login use for tripadvisor and yelp

        if (isset($string[0]) && isset($string[1]) && isset($string[2]) && isset($string[3])) { //remove extra content hai spaces

            $finalString = trim($string[0]);  // remove extra spaces

        } else {

            $finalString = implode(" ", $string);;

        }
        $convertdate = strtotime($finalString);
        $formatedDate = date('m-d-Y', $convertdate);

    }

    return $formatedDate;
}

function filterPhoneNumber($phone)
{
    $formatToReplace = array("+", " ", "-", "(", ")", ".");
    $replaceFormat = array("", "", "", "", "");
    $phone = str_replace($formatToReplace, $replaceFormat, $phone);

    if (is_numeric($phone)) {
        return ltrim($phone, '0');
    }

    return '';

}

function moduleList()
{
    return ['Local Marketing', 'Social Media', 'Website'];
}

function moduleSmallSiteList()
{
    return ['TA', 'GP', 'YP', 'FB'];

}

function moduleSiteList()
{
    return ['Tripadvisor', 'Google Places', 'Yelp', 'Facebook', 'Website'];

}

function moduleSocialList()
{
    return ['Twitter', 'Linkedin', 'Instagram', 'Facebook'];

}


/**
 * @param $day
 * @param string $extractWeek (next,previous)
 */
function extractWeekDays($day, $extractDays = 6)
{
    //dd($day);
// parse about any English textual datetime description into a Unix timestamp
    $timestamp = strtotime($day);
    $dateFormat = dateFormatUsing();

    for ($i = 0; $i <= $extractDays; $i++) {
        $date = strtotime("+$i day", $timestamp);
        $weekDates[$i]['activity_date'] = date($dateFormat, $date);
        $weekDates[$i]['count'] = 0;
    }

    return $weekDates;
}

//function extractWeekDays($day, $extractWeek = 'next')
//{
//    // parse about any English textual datetime description into a Unix timestamp
//    $timestamp = strtotime($day);
//    $dateFormat = dateFormatUsing();
//
//    for($i=0;$i<=7;$i++) {
//        $date = strtotime("+$i day", $timestamp);
//        $weekDates[] = date($dateFormat, $date);
//    }
//
//    return $weekDates;
//}

function dateFormatUsing($format = 'Y-m-d')
{
    return $format;
}

function getFormattedDate($date, $dateFormat = '')
{
    if ($dateFormat == '') {
        $dateFormat = dateFormatUsing();
    }

    $timestamp = strtotime(str_replace('-', '/', $date));

    if ($timestamp === FALSE) {
        $timestamp = strtotime(str_replace('/', '-', $date));
    }

    return date('Y-m-d', $timestamp);
}

function contentDiscoveryDateConversion($date)
{
    if ($date == '24 Hours') {
        $numberOfDay = 1;
        // $currentDate = Carbon::now();
        // $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    } else if ($date == 'Past Week') {
        $numberOfDay = 7;
        //  $currentDate = Carbon::now()->subWeek(1);
        // $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    } else if ($date == 'Past Month') {
        $numberOfDay = 30;
        // $currentDate = Carbon::now()->subMonth(1);
        // $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    } else if ($date == 'Past 6 Months') {
        $numberOfDay = 282;
        // $currentDate = Carbon::now()->subMonth(6);
        // $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    } else if ($date == 'Past Year') {
        $numberOfDay = 365;
        // $currentDate = Carbon::now()->subYear(1);
        // $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    } else if ($date == 'Past 2 Years') {
        $numberOfDay = 730;
        // $currentDate = Carbon::now()->subYear(2);
        // $formatedDate = Carbon::createFromFormat('Y-m-d H:i:s', $currentDate)->format('m-d-Y');
    }
    return $numberOfDay;
}

/**
 * @param $newNumber ($newNumber, today)
 * @param int $originalNumber ($newNumber, yesterday)
 * @param string $type
 * @return array
 */
function insightTitle($newNumber = 0, $originalNumber = 0, $type = 'week', $category = 'RV', $id = '')
{
    $data['objective'] = '';
    $data['insightDescription'] = '';

    if ($category == 'RV' || $category == 'LK') {
        if ($type == 'week') {
            $increase = $newNumber - $originalNumber;
            if ($originalNumber == 0) {
                $originalNumber = 1;
            }
            $increase = $increase / $originalNumber * 100;
            $increase = round($increase, 2);

            if ($increase == 0 || strpos($increase, '-') !== false) {
                $increase = str_replace('-', '', $increase);

                $data['insightTitle'] = "Down $increase% from previous week";
                $data['insightStatus'] = "down";
            } else {
                $data['insightTitle'] = "Up $increase% from previous week";
                $data['insightStatus'] = "up";
            }
        } else {
            $diff = $newNumber - $originalNumber;
            if ($diff == 0 || strpos($diff, '-') !== false) {
                $diff = str_replace('-', '', $diff);
                $data['insightTitle'] = "Down $diff from yesterday";
                $data['insightStatus'] = "down";
            } else {
                $data['insightTitle'] = "Up $diff from yesterday";
                $data['insightStatus'] = "up";
            }
        }

        if ($category == 'LK') {
            $data['insightDescription'] = "Click here how to learn more on how you can increase your Facebook page likes.";
        } else {
            $data['insightDescription'] = "Click here how to learn more about how you can increase your reviews.";
        }
    } elseif ($category == 'RG') {
        if ($newNumber >= 1 && $newNumber < 3) {
            $data['insightTitle'] = "Poor customer rating";
            $data['insightDescription'] = "Your customers rate your services or products low. Click here for the task on how to improve your customer satisfactory rating.";
            $data['insightStatus'] = "down";
        } elseif ($newNumber >= 3 && $newNumber < 4) {
            $data['insightTitle'] = "Average customer rating";
            $data['insightDescription'] = "Your customers are not exactly blown away by your service but you can do better. Click here to read the task on how to improve your customer satisfactory rating.";
            $data['insightStatus'] = "average";
        } elseif ($newNumber >= 4 && $newNumber < 5) {
            $data['insightTitle'] = "Good customer rating";
            $data['insightDescription'] = "Your customers are happy with your services but there’s still a little room for improvement. Click here to read the task on how to improve your customer satisfactory rating.";
            $data['insightStatus'] = "up";
        } elseif ($newNumber == 5) {
            $data['insightTitle'] = "Perfect customer rating!";
            $data['insightDescription'] = "";

            $data['insightStatus'] = "up";
        } else {
            $data['insightTitle'] = "Not received any feedback";
            $data['insightDescription'] = "You have not received any feedback. Click here to learn how to get your customers to leave feedback on your site.";
            $data['insightStatus'] = "down";
            $data['objective'] = $id;
        }
    } elseif ($category == 'analytics' || $category == 'PV') {
        if ($type == 'week') {
            $diff = $newNumber / 7;
            $diff = round($diff, 2);

            $data['insightTitle'] = "Average of $diff pageviews <br> for last 7 days";
            $data['insightStatus'] = "up";
            $data['insightDescription'] = "Click here to learn how you can increase your website traffic.";
        } elseif ($type == 'all') {
            $diff = $newNumber / 30;
            $diff = round($diff, 2);

            $data['insightTitle'] = "Average of $diff pageviews <br> for last 30 days";
            $data['insightStatus'] = "up";
            $data['insightDescription'] = "Click here to learn how you can increase your website traffic.";
        } elseif ($type == 'day') {
            $diff = $newNumber - $originalNumber;
            if ($diff == 0 || strpos($diff, '-') !== false) {
                $diff = str_replace('-', '', $diff);
                $data['insightTitle'] = "Down $diff from yesterday";
                $data['insightStatus'] = "down";
            } else {
                $data['insightTitle'] = "Up $diff from yesterday";
                $data['insightStatus'] = "up";
            }

            $data['insightDescription'] = "Click here how to learn more on how you can increase your website traffic.";
        } else {
            $data['insightTitle'] = "Google Analytics not detected <br> on website.";
            $data['insightDescription'] = "We have not detected your Google Analytics code on your website. <View task> on how to add GA to your website.";
            $data['insightStatus'] = "down";
        }
    } else {
        if ($newNumber >= 0 && $newNumber < 70) {
            $data['insightTitle'] = "Poor optimization";
            $data['insightDescription'] = "This page is not optimized and is likely to deliver a slow user experience. Click here to read the task on how to optimize your website.";
            $data['insightStatus'] = "down";
        } elseif ($newNumber >= 70 && $newNumber < 85) {
            $data['insightTitle'] = "Average optimization";
            $data['insightDescription'] = "This page is missing some common performance optimizations that may result in a slow user experience. Click here to read the task on how to optimize your website.";
            $data['insightStatus'] = "average";
        } elseif ($newNumber >= 85 && $newNumber <= 100) {
            $data['insightTitle'] = "Great optimization";
            $data['insightDescription'] = "“Nice work! This page applies most performance best practices and should deliver a good user experience. See how you can optimize your website further. Click here.";
            $data['insightStatus'] = "up";
        }
    }

    $data['insightDescription'] = str_replace('Click here', '<Click here>', $data['insightDescription']);

    if ($data['insightDescription'] != '' && $data['objective'] == '') {
        $data['objective'] = $id;
    }


    if (empty($data['insightTitle'])) {
        return $data = [
            'insightTitle' => '',
            'insightDescription' => '',
            'insightStatus' => '',
            'objective' => '',
        ];
    }

    return $data;
}

function hasWord($word, $text)
{
    $patt = "/(?:^|[^a-zA-Z0-9])" . preg_quote($word, '/') . "(?:$|[^a-zA-Z0-9])/i";
    return preg_match($patt, $text);
}


function randomString($length = 8)
{
    $str = "";
    $characters = array_merge(range('A', 'Z'), range('a', 'z'), range('0', '9'));
    $max = count($characters) - 1;
    for ($i = 0; $i < $length; $i++) {
        $rand = mt_rand(0, $max);
        $str .= $characters[$rand];
    }
    return $str;
}


function getThirdPartyTypeLongToShortForm($type)
{

    if ($type == 'Tripadvisor') {
        $shortType = 'TA';
    } else if ($type == 'Google Places') {
        $shortType = 'GP';
    } else if ($type == 'Yelp') {
        $shortType = 'YP';
    } else if ($type == 'Facebook') {
        $shortType = 'FB';
    }
    return $shortType;
}

function getThirdPartyTypeShortToLongForm($type)
{
    $longType = '';
    if ($type == 'TA') {
        $longType = 'Tripadvisor';
    } else if ($type == 'GP') {
        $longType = 'Google Places';
    } else if ($type == 'YP') {
        $longType = 'Yelp';
    } else if ($type == 'FB') {
        $longType = 'Facebook';
    }
    return $longType;
}

function compareStringGetSubSetResult($scrapperName, $userName)
{

    $userName = preg_replace("/[^a-zA-Z]/", "", strtolower($userName));
    $scrapperName = preg_replace("/[^a-zA-Z]/", "", strtolower($scrapperName));
    if (strpos($scrapperName, $userName) !== false) {
        $res = 'true';
    } else {
        $res = 'false';
    }
    return $res;
}


function get_longest_common_subsequence($string_1, $string_2)
{
    $string_1_length = strlen($string_1);
    $string_2_length = strlen($string_2);
    $return = '';

    if ($string_1_length === 0 || $string_2_length === 0) {
        // No similarities
        return $return;
    }

    $longest_common_subsequence = array();

    // Initialize the CSL array to assume there are no similarities
    $longest_common_subsequence = array_fill(0, $string_1_length, array_fill(0, $string_2_length, 0));

    $largest_size = 0;

    for ($i = 0; $i < $string_1_length; $i++) {
        for ($j = 0; $j < $string_2_length; $j++) {
            // Check every combination of characters
            if ($string_1[$i] === $string_2[$j]) {
                // These are the same in both strings
                if ($i === 0 || $j === 0) {
                    // It's the first character, so it's clearly only 1 character long
                    $longest_common_subsequence[$i][$j] = 1;

                } else {
                    // It's one character longer than the string from the previous character
                    $longest_common_subsequence[$i][$j] = $longest_common_subsequence[$i - 1][$j - 1] + 1;
                }

                if ($longest_common_subsequence[$i][$j] > $largest_size) {
                    // Remember this as the largest
                    $largest_size = $longest_common_subsequence[$i][$j];
                    // Wipe any previous results
                    $return = '';
                    // And then fall through to remember this new value
                }

                if ($longest_common_subsequence[$i][$j] === $largest_size) {
                    // Remember the largest string(s)
                    $return = substr($string_1, $i - $largest_size + 1, $largest_size);
                }
            }
            // Else, $CSL should be set to 0, which it was already initialized to
        }
    }

    // Return the list of matches
    return $return;
}


function createSlug($title, $id = 0)
{
    // Normalize the title
    //$slug = str_slug($title);
    $slug = $title;
    // Get any that could possibly be related.
    // This cuts the queries down by doing it once.
    $slug = str_replace('-', '', $slug);
    $allSlugs = getRelatedSlugs($slug, $id);
    // If we haven't used it before then we are all good.
    if (!$allSlugs->contains('slug', $slug)) {
        return $slug;
    }
    // Just append numbers like a savage until we find not used.
    for ($i = 1; $i <= 10; $i++) {
        $newSlug = $slug . $i;
        if (!$allSlugs->contains('slug', $newSlug)) {
            return $newSlug;
        }
    }
    throw new \Exception('Can not create a unique slug');
}

function getRelatedSlugs($slug, $id = 0)
{
    return Business::select('slug')->where('slug', 'like', $slug . '%')
        ->where('business_id', '<>', $id)
        ->get();
}

function stringToArray($string)
{
    $Arr = explode(',', $string);
    return $Arr;
}

function arrayToString($string)
{
    $Arr = implode(',', $string);
    return $Arr;
}

function replaceSpaceWithDashes($string)
{
    //Lower case everything
    $string = strtolower($string);
    $string = preg_replace("/[\s]/", "-", $string);
    return $string;
}

function calculatePrice($cost)
{
    $price = ($cost * 2.33333333) / 0.8;
    $price = round($price, 2);
    return $price;
}

function calculateProfitPrice($cost, $shippingCost)
{
    $price = ($cost + $shippingCost) * 2.33333333 / 0.8;
    $price = round($price, 2);
    return $price;
}

function calculateMsrp($price)
{
    $msrp = $price * 1.8;
    $msrp = round($msrp, 2);
    return $msrp;
}

function calculateProfit($price, $cost)
{
    $profit = $price - $cost;
    return $profit;
}

function checkFile($url)
{
    $result = get_headers(trim($url));
    return stripos($result[0], "200 OK") ? true : false; //check if $result[0] has 200 OK
}

function getUserIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        //ip from share internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        //ip pass from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

function getIntegerValue($num)
{
    $number = preg_replace('/[^0-9\.]/', '', $num);
    return !empty($number) ? $number : 0;
}

function getStockIntegerValue($num)
{
    if (strpos($num, 'or more') !== false) {
        $number = strtok($num, " ");
    } else {
        $number = preg_replace('/[^0-9\.]/', '', $num);
    }
    return !empty($number) ? $number : 0;
}

function parseEbayQuantity($string)
{
    if (strpos($string, 'or more') !== false) {
        $number = 11;
    } else if (strpos($string, 'More than') !== false) {
        $number = 11;
    } else if (strpos($string, 'Last one') !== false) {
        $number = 1;
    } else if ($string == 'Limited quantity available') {
        $number = 11;
    } else if ($string == '0 available') {
        $number = 0;
    } else if ($string == 'Limited quantity available') {
        $number = 11;
    } else {
        $number = preg_replace('/[^0-9\.]/', '', $string);
        $number = (int)$number;
    }
    return !empty($number) ? $number : 0;
}

function checkDollarValue($string)
{
    if (strpos($string, '$') !== false) {
        $ebay_product_shipping_cost = preg_replace('/[$]/', '', $string);
    } else {
        $ebay_product_shipping_cost = 0;
    }
    return $ebay_product_shipping_cost;

}

function convertSystemTZtoUserTZ($timeZone, $campaignTime): array
{
    $sign = substr($timeZone, 0, 1);
    $hours = $sign . substr($timeZone, 1, 2);
    $minutes = $sign . substr($timeZone, 3);
    return [
        "currentTime" => date("Y-m-d H:i", strtotime(Carbon::now()->addHours($hours)->addMinutes($minutes))),
        "campaignTime" => date_format(date_create($campaignTime), 'Y-m-d H:i')
    ];
}

function getPercentage($portion, $total, $average = 0): string
{
    $result = $total > 0 ? ($portion / $total) * 100 : 0;
    if ($average > 0)
        $result /= $average;
    return number_format((float)$result, 2);
}

function getKeyFromValueArray(array $array, $value): string
{
    $newArray = array_flip($array);
    return $newArray[$value];
}

function daysName($value)
{
    $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    if (in_array($value, $days)) {
        echo "true";
    } else {
        return "false";
    }
}

function getLastWeekDays()
{
    $date2 = Carbon::now()->subDays(6)->format('Y-m-d');
    $date1 = Carbon::now()->format('Y-m-d');
    $period = CarbonPeriod::create($date2, $date1);
    $dates = array();
    foreach ($period as $date) {
        array_push($dates, $date->format('Y-m-d'));
    }
    return $dates;
}

function responseForDailyFilters($dates, $obj, $responseType, $dateColumn, $labelColumn = 'name', $dateColumnName = 'date')
{
    $responseArray = [];
    foreach ($dates as $date) {
        $key = array_keys(array_column($obj, $dateColumn), $date);
        if (!empty($key)) {
            if (isset($responseType[1])) {
                $responseArray[] = [
                    $dateColumnName => $obj[$key[0]][$dateColumn],
                    $labelColumn => $obj[$key[0]]['dayname'],
                    $responseType[0] => $obj[$key[0]]['first_total'],
                    $responseType[1] => $obj[$key[0]]['second_total'],
                ];
            } else {
                $responseArray[] = [
                    $dateColumnName => $obj[$key[0]][$dateColumn],
                    $labelColumn => $obj[$key[0]]['dayname'],
                    $responseType[0] => $obj[$key[0]]['first_total'],
                ];
            }
        } else {
            if (isset($responseType[1])) {
                $responseArray[] = [
                    $dateColumnName => $date,
                    $labelColumn => $newDate = date("D", strtotime($date)),
                    $responseType[0] => 0,
                    $responseType[1] => 0,
                ];
            } else {
                $responseArray[] = [
                    $dateColumnName => $date,
                    $labelColumn => $newDate = date("D", strtotime($date)),
                    $responseType[0] => 0,
                ];
            }
        }
    }
    return $responseArray;
}

function getLastFourWeekDays()
{
    $weeks = array();
    $week1 = Carbon::now()->subDays(6)->format('Y-m-d');
    $week2 = Carbon::now()->subDays(13)->format('Y-m-d');
    $week3 = Carbon::now()->subDays(20)->format('Y-m-d');
    $week4 = Carbon::now()->subDays(27)->format('Y-m-d');
    $weeks = [$week1, $week2, $week3, $week4];
    return $weeks;
}

function responseForMonthFilter($weeks, $obj, $responseType, $column, $labelColumn = 'name')
{
    $week1Date = $obj->where($column, '>=', $weeks[0])->toArray();
    $week2Date = $obj->where($column, '>=', $weeks[1])->where($column, '<', $weeks[0])->toArray();
    $week3Date = $obj->where($column, '>=', $weeks[2])->where($column, '<', $weeks[1])->toArray();
    $week4Date = $obj->where($column, '>=', $weeks[3])->where($column, '<', $weeks[2])->toArray();
    if (isset($responseType[1])) {
        $responseArray = [[
            'date' => $weeks[3],
            $labelColumn => $weeks[3],
            $responseType[0] => empty($week4Date) ? 0 : array_sum(array_column($week4Date, 'first_total')),
            $responseType[1] => empty($week4Date) ? 0 : array_sum(array_column($week4Date, 'second_total')),

        ], [
            'date' => $weeks[2],
            $labelColumn => $weeks[2],
            $responseType[0] => empty($week3Date) ? 0 : array_sum(array_column($week3Date, 'first_total')),
            $responseType[1] => empty($week3Date) ? 0 : array_sum(array_column($week3Date, 'second_total')),
        ], [
            'date' => $weeks[1],
            $labelColumn => $weeks[1],
            $responseType[0] => empty($week2Date) ? 0 : array_sum(array_column($week2Date, 'first_total')),
            $responseType[1] => empty($week2Date) ? 0 : array_sum(array_column($week2Date, 'second_total')),

        ], [
            'date' => $weeks[0],
            $labelColumn => $weeks[0],
            $responseType[0] => empty($week1Date) ? 0 : array_sum(array_column($week1Date, 'first_total')),
            $responseType[1] => empty($week1Date) ? 0 : array_sum(array_column($week1Date, 'second_total')),
        ]];
    } else {
        $responseArray = [[
            'date' => $weeks[3],
            $labelColumn => $weeks[3],
            $responseType[0] => empty($week4Date) ? 0 : array_sum(array_column($week4Date, 'first_total')),
        ], [
            'date' => $weeks[2],
            $labelColumn => $weeks[2],
            $responseType[0] => empty($week3Date) ? 0 : array_sum(array_column($week3Date, 'first_total')),
        ], [
            'date' => $weeks[1],
            $labelColumn => $weeks[1],
            $responseType[0] => empty($week2Date) ? 0 : array_sum(array_column($week2Date, 'first_total')),
        ], [
            'date' => $weeks[0],
            $labelColumn => $weeks[0],
            $responseType[0] => empty($week1Date) ? 0 : array_sum(array_column($week1Date, 'first_total')),
        ]];
    }
    return $responseArray;
}

function getLastThreeMonths()
{
    $month1 = Carbon::now()->format('F');
    $month2 = Carbon::now()->subMonth(1)->format('F');
    $month3 = Carbon::now()->subMonth(2)->format('F');
    $months = [$month3, $month2, $month1];
    return $months;
}

function responseForLastThreeMonthFilter($months, $obj, $responseType, $column, $labelColumn = 'name')
{
    $responseArray = [];
    foreach ($months as $month) {
        $key = array_keys(array_column($obj, 'monthname'), $month);
        if (!empty($key)) {
            if (isset($responseType[1])) {
                $responseArray[] = [
                    'date' => $obj[$key[0]][$column],
                    $labelColumn => $obj[$key[0]]['monthname'],
                    $responseType[0] => $obj[$key[0]]['first_total'],
                    $responseType[1] => $obj[$key[0]]['second_total'],
                ];
            } else {
                $responseArray[] = [
                    'date' => $obj[$key[0]][$column],
                    $labelColumn => $obj[$key[0]]['monthname'],
                    $responseType[0] => $obj[$key[0]]['first_total'],
                ];
            }
        } else {
            if (isset($responseType[1])) {
                $responseArray[] = [
                    'date' => $month,
                    $labelColumn => $month,
                    $responseType[0] => 0,
                    $responseType[1] => 0,
                ];
            } else {
                $responseArray[] = [
                    'date' => $month,
                    $labelColumn => $month,
                    $responseType[0] => 0,
                ];
            }
        }
    }
    return $responseArray;
}

function checkCSVFormat($fileName)
{
    $i = 1;
    $file = fopen($fileName, "r+");
    while (($data = fgetcsv($file, 4000, ",")) !== FALSE) {  //read the csv file

        if ($i == 1) {
            if (isset($data[0]) && $data[0] == 'email' && isset($data[1]) && $data[1] == 'first_name' && isset($data[2]) && $data[2] == 'last_name' && isset($data[3]) && $data[3] == 'phone_number' && isset($data[4]) && $data[4] == 'address_one' && isset($data[5]) && $data[5] == 'address_two' && isset($data[6]) && $data[6] == 'city' && isset($data[7]) && $data[7] == 'country' && isset($data[8]) && $data[8] == 'state' && isset($data[9]) && $data[9] == 'zip_code' && isset($data[10]) && $data[10] == 'customer_ip' && !isset($data[11])) {
                return true;
            } else {
                return false;
            }
        }

    }
}

if (!function_exists('paginationAndSearch')) {


    function paginationAndSearch($request, &$perPage, &$query, $columns = [])
    {
        if ($request->has('per_page') && $request->per_page != null) {
            $perPage = $request->per_page;
        }

        if ($request->has('searchData') && $request->searchData != null) {
            $query->where(function ($query) use ($request, $columns) {
                foreach ($columns as $column) {
                    $query->orWhere($column, 'LIKE', '%' . $request->searchData . '%');
                }
            });
        }
    }


function storeCache($key, $expiryTime, $callBackFunction)
{
    return \Illuminate\Support\Facades\Cache::remember($key, $expiryTime, function () use ($callBackFunction) {
        return call_user_func($callBackFunction);
    });
}

if(!function_exists('resetEmailLimit')){
function resetEmailLimit(&$requestsCount, $email)
{
    $now = Carbon::now();
    $todayRequests = DB::table('password_resets')->select('id', 'created_at')
        ->where(['email' => $email])
        ->whereDay('created_at', $now->day)
        ->get();

    if(count($todayRequests)){
        foreach($todayRequests as $req){
            $reqTime = Carbon::parse($req->created_at)->format('H:i');
            $currentTime = $now->format('H:i');
            if($reqTime == $currentTime){
                $requestsCount++;
            }
        }
    }
}
}

if(!function_exists('finalSpfSettings')){
function finalSpfSettings($existingString)
{
    $updatedString = $existingString;
    $isExist = str_contains($existingString, '~all');
    $isExist1 = str_contains($existingString, '-all');
    if($isExist){
        $word = "~all";
        $updatedString = str_replace($word, "include:_spf.smtp.com ~all",$updatedString);
    }
    else if($isExist1){
        $word = "-all";
        $updatedString = str_replace($word, "include:_spf.smtp.com -all",$updatedString);
    }else{
        $word = "~all";
        $updatedString .= " include:_spf.smtp.com ~all";
    }
    return $updatedString;
}
}

if(!function_exists('backendRedirectIncognito()')){
    function backendRedirectIncognito($isNew, $generalSettings)
    {
        $baseUrl = getenv('marketing_APP_URL');
        if($isNew){
            $url = $baseUrl . '/thank-you';
            if(!((int)$generalSettings->is_default_thank_page)){
                $url = $generalSettings->thank_page_url;
            }
        }else{
            $url = $baseUrl . '/already-subscribed';
            if(!((int)$generalSettings->is_default_already_subscribe_page)){
                $url = $generalSettings->already_subscribe_page_url;
            }
        }
        return $url;
    }
}

// Managing auto-upgrade
if(!function_exists('isUserExceeded')){
    function isUserExceeded($user=null)
    {
        if(is_null($user)){
            $user = Auth::user();
        }
        $userContacts = Customer::where('user_id', $user->id)
                            ->where('is_subscribed',1)
                            ->where('is_supression', 0)
                            ->where('subscription_status', 0)->count();
        Log::info("customers $userContacts");
       //  $userContacts = 2501;
        $userSubscription = Subscription::where('user_id', $user->id)->first()->toArray();
        if(!$userSubscription || is_null($userSubscription['marketing_plan_id'] )){
            abort(404, "User Plan not found in database");
        }

        $plan = Plan::where('id', $userSubscription['marketing_plan_id'])->first()->toArray();
        if($userContacts > $plan['subscribers']){
            // call identifyUpgradedPlan(); if user exceeded
            return ['isUserExceeded' => true, 'userSubscription' => $userSubscription,'plan' => $plan, 'userContacts' => $userContacts];
        }
        return ['isUserExceeded' => false];
    }
}

if(!function_exists('identifyUserPlan')){
    function identifyUpgradedPlan($userPlanInfo)
    {
        $userContacts = $userPlanInfo['userContacts'];
        // from plans table user plan details.
        $currentPlanDetail = $userPlanInfo['plan'];
        // from subscriptions table
        $currentPlan = $userPlanInfo['userSubscription'];

        // plans based on plan type either month or year.
        $plans = Plan::where('plan_type', $currentPlanDetail['plan_type'])->get()->toArray();

        // on call if isUserExceeded is true.
        $userUpgradePlan = [];
        for ($i = 0; $i < count($plans); $i++) {
            if ($plans[$i]['subscribers'] < $currentPlanDetail['subscribers']) {
                continue;
            }
            $plan = $plans[$i];
            $planContacts = (int)$plan['subscribers'];
            if ($userContacts <= $planContacts) {
                $userUpgradePlan = $plan;
                break;
            }
        }

        if (count($userUpgradePlan) == 0) {
            $userUpgradePlan = $plans[(count($plans) - 1)];
        }
        $userUpgradePlan['user_id'] = $currentPlan['user_id'];
        return $userUpgradePlan;
        // call savePlanHistory()
    }
}

if(!function_exists('savePlanHistory')){
    function savePlanHistory($userPlan,$upgradedPlan, $userContacts)
    {
        // Only call if UserExceeded his limit and upgrade needed.
        $oldPlan = PlanHistory::where('user_id', $userPlan->user_id)->orderBy('id', 'desc')->first();

        $discountPercentage = 0;
        $plan = $userPlan->toArray();
        $response = false;
        $plan_history = [
            'user_id' => $userPlan->user_id,
            'marketing_plan_id' => $userPlan->marketing_plan_id,
            'plan_type' => 'current',
            'total_contacts' => $userContacts,
            'subscription_level' => 'auto',
            'subscription_date'  => date('Y-m-d'),
            'status' => 'active',
            'cost' => $upgradedPlan['cost'],
            'discount_percentage' => $discountPercentage,
            'billing_cycle_start' => $userPlan->starts_at,
            'billing_cycle_end' => $userPlan->ends_at,
        ];

        // after successful insertion in database
        $inserted = PlanHistory::insert($plan_history);
        if ($inserted) {
            $response = $plan_history;
            if($oldPlan){
                $oldPlan->plan_type = "old";
                $oldPlan->subscription_end_date = date('Y-m-d');
                $oldPlan->status = "inactive";
                $oldPlan->save();
            }
        }
        return $response;
    }
}

if(!function_exists('getPlanUsageCost')){
    function getPlanUsageCost($cost, $subscriptionDate, $subscriptionEndDate)
    {
        $to = \Carbon\Carbon::createFromFormat('Y-m-d H:s:i', $subscriptionDate);
        $from = \Carbon\Carbon::createFromFormat('Y-m-d H:s:i', $subscriptionEndDate);

        $diff_in_days = $to->diffInDays($from);
        $usageCost = ($cost/30) * $diff_in_days;
        if(is_null($usageCost)){
            $usageCost = 0;
        }
        return ['usage_days' => $diff_in_days, 'usage_cost' => $usageCost];
    }
}
// Managing auto-upgrade

if(!function_exists('upgradeEmailPayload')){
    function upgradeEmailPayload($upgradedPlan)
    {
        $duration = "This plan will remain active until its subscribers limit is reached.";
        $upgradePayload = [
            'user_id' => $upgradedPlan['user_id'], 'subscribers' => $upgradedPlan['subscribers'],
            'plan_type' => $upgradedPlan['plan_type'],'price' => $upgradedPlan['cost']
        ];
        $upgradePayload['duration'] = $duration;
        return $upgradePayload;
    }
}

if(!function_exists('getUserDiscount')){
    function getUserDiscount($user_id, $plan)
    {
        $response = [
            'is_discount_allowed' => false,
            'discount_percentage' => 0,
        ];
        $couponCode = DB::table('coupon_codes')->select('id','user_id','title','is_expired')
        ->where('user_id', $user_id)->orderBy('id','desc')->first();

        if($couponCode && ( ($plan['id'] == 1 && $plan['cost'] == 59) || ($plan['id'] == 36 && $plan['cost'] == 590) ) ){
            if(!$couponCode->is_expired){
                $couponTitle = $couponCode->title;
                if($couponTitle == "CBSUPER" || $couponTitle == "marketing100"){
                    $response['is_discount_allowed'] = true;
                    $response['discount_percentage'] = 50;
                }
            }
        }

        return $response;
    }
}

if (!function_exists('exif_imageType_helper')){
    function exif_imageType_helper($file)
    {
        return exif_imagetype($file);
    }
}
if (!function_exists('checkSuppression')){
    function checkSuppression(): bool
    {
        return DB::table('settings')->first()->suppression == 1;
    }
}
if (!function_exists('errorLogs')){
    function errorLogs(Exception $exception,$functionName)
    {
        Log::error("Exception :  $functionName : ", [
            "lineNo"   =>   $exception->getLine(),
            "errorMsg" => $exception->getMessage(),
            "fileName" => $exception->getFile()
        ]);
    }
}
if (!function_exists('checkReviewEnabled')){
    function checkReviewEnabled(): bool
    {
        return DB::table('settings')->first()->is_review_enabled == 1;
    }
}
if (!function_exists('getDiscountedAmount')){
    function getDiscountedAmount($totalCost,$userId,$subscribers=null): array
    {
        $coupon = CouponCode::where('user_id',$userId)->first();
        $discount = SpCcDiscount::where('coupon_code',$coupon->title)->where('is_active', 1)->first();
        $getDiscount = SpCcDiscountTier::select('id','discount_id','min_contacts','max_contacts','percentage')
            ->where('discount_id', $discount->id)
            ->where('min_contacts','<=',$subscribers)
            ->where('max_contacts','>=',$subscribers)->first();
        $discountedPrice = $totalCost - (($totalCost / 100) * $getDiscount->percentage);
        return [
          'discounted_amount'  => $discountedPrice,
          'percentage'  => $getDiscount->percentage
        ];
    }
}
}
