<?php
namespace App\Services;

use App\Traits\GlobalResponseTrait;
use App\Models\User;
use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\Log;
use Tymon\JWTAuth\JWTAuth;

class UserAuthValidator
{
    use GlobalResponseTrait;

    /**
     * This method retrieve the user
     * @param $token
     * @return mixed (200, 401, 1000, 7)
     */
    public function checkUserAuth($token)
    {
        $userData = '';
        try {
            if($token)
            {
                $user = JWTAuth::toUser($token);

                if (!empty($user)) {

                    if($user->user_type == 'user'){
                        $userData = $user;
                        return $this->helpReturn('Authentication Successful', $userData);
                    }

                    $response = response()->json(
                        [
                            'code' => 401,
                            'error'=>'You are not authorize for this action.'
                        ]
                    );

                }
            }
            else
            {
                $response = response()->json(
                    [
                        'code' => 401,
                        'error'=>'Token missing.'
                    ]
                );
            }

        } catch (Exception $e) {
            Log::info("UserAuthValidator > " . $e->getMessage());

            if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenInvalidException){
                $response = response()->json(
                    [
                        'code' => 401,
                        'error'=>'Token is Invalid'
                    ]
                );
            }else if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenExpiredException){
                $response = response()->json(
                    [
                        'code' => 7,
                        'error'=>'Token is Expired'
                    ]
                );
            }else{
                $response = response()->json
                (
                    [
                        'code' => 1000,
                        'error'=>'Something is wrong'
                    ]
                );
            }
        }

        if($userData)
        {
            return $this->helpReturn('You still visit the site.', $userData);
        }
        else
        {
            if(empty($response)) {
                $response = response()->json(
                    [
                        'code' => 7,
                        'error' => 'Token is Expired.'
                    ]
                );
            }

            return $this->helpError($response->original['code'], $response->original['error']);
        }

    }

    public function checkAdminAuth($token)
    {
        $userData = '';
        try {
            if($token)
            {
                $userObj = JWTAuth::toUser($token);
                $user = User::where('id',$userObj->id)->with('role')->first();

                if (!empty($user)) {
                    if($user->user_type == 'admin'){
                        $userData = $user;
                        return $this->helpReturn('Authentication Successful', $userData);
                    }

                    $response = response()->json(
                        [
                            'code' => 401,
                            'error'=>'You are not authorize for this action.'
                        ]
                    );
                }
            }
            else
            {
                $response = response()->json(
                    [
                        'code' => 401,
                        'error'=>'Token missing.'
                    ]
                );
            }

        } catch (Exception $e) {
            Log::info("UserAuthValidator > " . $e->getMessage());

            if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenInvalidException){
                $response = response()->json(
                    [
                        'code' => 401,
                        'error'=>'Token is Invalid'
                    ]
                );
            }else if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenExpiredException){
                $response = response()->json(
                    [
                        'code' => 7,
                        'error'=>'Token is Expired'
                    ]
                );
            }else{
                $response = response()->json
                (
                    [
                        'code' => 1000,
                        'error'=>'Something is wrong'
                    ]
                );
            }
        }

        if($userData)
        {
            return $this->helpReturn('You still visit the site.', $userData);
        }
        else
        {
            if(empty($response)) {
                $response = response()->json(
                    [
                        'code' => 7,
                        'error' => 'Token is Expired.'
                    ]
                );
            }

            return $this->helpError($response->original['code'], $response->original['error']);
        }

    }


}
