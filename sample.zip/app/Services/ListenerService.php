<?php
/**
 * Created by PhpStorm.
 * User: Atta ul Mohsin
 * Date: 1/31/2017
 * Time: 2:02 AM
 */
namespace App\Services;

use App\Traits\GlobalErrorHandlingTrait;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Config;
use GuzzleHttp\Client;
class ListenerService
{
    use GlobalErrorHandlingTrait;

    public function uploadCSV($data)
    {
        $url = Config::get('marketing.listener_url').'/csv-upload-listner-call';
        $method = 'POST';
        $args = [
            'URL' => $url,
            'METHOD' => $method,
            'DATA' => $data,
        ];
        $response = $this->call($args);
        return $response;
    }


    public function call($args)
    {
        try{
            $client = new Client();
            if($args['METHOD'] == 'POST'){
                $response = $client->post($args['URL'],
                    ['form_params' => $args['DATA']]
                );
            }else if($args['METHOD'] == 'GET'){
                $response = $client->get($args['URL']);
            }
            else if($args['METHOD'] == 'DELETE'){
                $response = $client->delete($args['URL']);
            }
            $response = $response->getBody()->getContents();
            return $response;

        } catch (\Exception $e) {
            return false;
        }
    }
}
