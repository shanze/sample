<?php

namespace App\Services;

use App\Traits\GlobalResponseTrait;
use Modules\Campaign\Entities\CampaignEntity;

class ResponseService
{
    use GlobalResponseTrait;
    public function getDataResponse($data,$dataName){
        if ($data){
            return $this->helpReturn("$dataName Data: ", $data);
        }else{
            return $this->helpError(404,"Record not found","Invalid $dataName id");
        }
    }
}
