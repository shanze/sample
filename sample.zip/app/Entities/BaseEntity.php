<?php

namespace App\Entities;

use App\Services\ListenerService;
use App\Traits\GlobalResponseTrait;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\Auth;
use Modules\AutoResponder\Entities\Models\ArTriggerAction;
use Modules\AutoResponder\Entities\Models\AutoResponderProcessing;
use Illuminate\Support\Facades\Log;

abstract class BaseEntity
{
    use GlobalResponseTrait;
    const _DAILY = 7;
    const _MONTHLY = 30;
    const _THREE_MONTHS = 90;
    protected $listenerService;
    public function __construct()
    {
        $this->listenerService = new ListenerService();
    }
    public function getDataResponse($data,$dataName){
        if ($data){
            return $this->helpReturn("$dataName Data: ", $data);
        }else{
            return $this->helpError(404,"Record not found","Invalid $dataName id");
        }
    }

    public static function getPeriod($period): array
    {
        $timePeriod = Carbon::now();
        $divider = false;
        if ($period == 'daily') {
            $timePeriod = $timePeriod->subDays(self::_DAILY - 1);
            $divider = self::_DAILY;
            $dataPoints = getLastWeekDays();
        }elseif($period == 'month'){
            $timePeriod = $timePeriod->subDays(self::_MONTHLY - 1);
            $divider = self::_MONTHLY;
            $dataPoints = getLastFourWeekDays();
        }elseif ($period == 'three_month') {
            $timePeriod = $timePeriod->subDays(self::_THREE_MONTHS - 1);
            $divider = self::_THREE_MONTHS;
            $dataPoints = getLastThreeMonths();
        }
        $dateTime = date_format($timePeriod,"Y-m-d") . " 00:00" ;
        return [
          'time_period' => $dateTime,
          'divider' => $divider,
          'data_points' => $dataPoints,
        ];
    }
    public function getDateRange($startDate=null,$endDate=null): array
    {
        if (!$startDate && !$endDate) {
            $startDate = Carbon::now()->format("Y-m-d");
            $endDate = Carbon::now()->format("Y-m-d");
        }
        $startDate .= " 00:00:00";
        $endDate .= " 23:59:59";
        return [
          "from" => $startDate,
          "to" => $endDate
        ];
    }

}
