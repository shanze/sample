<?php

namespace App\Observers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Modules\Campaign\Entities\Models\Campaign;
use Modules\Campaign\Entities\Models\Email;

class EmailObserver
{
    /**
     * Handle the Email "created" event.
     *
     * @param  \App\Models\Email  $email
     * @return void
     */
    public function created(Email $email)
    {
    }

    /**
     * Handle the Email "updated" event.
     *
     * @param  \App\Models\Email  $email
     * @return void
     */
    public function updated(Email $email)
    {
        $changeStatus = ($email->wasChanged('subject') || $email->wasChanged('pre_header')) || $email->wasChanged('body_content');
        if($changeStatus && Auth::user()->user_emails_status == 0){
            Email::where('id', $email->id)->update(['review_status' => "pending"]);
            if (!empty($email->campaign_id)){
                $campaign = Campaign::find($email->campaign_id);
                if ($campaign->review_status != 'approved' && Auth::user()->user_emails_status == 0){
                    $campaign->review_status = 'pending';
                    $campaign->save();
                }
            }
        }
    }

}
