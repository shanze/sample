<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\Audience\Database\Seeders\CustomerSeederTableSeeder;
use Modules\Audience\Database\Seeders\ListSeederTableSeeder;
use Modules\Audience\Database\Seeders\SenderProfileSeederTableSeeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            ListSeederTableSeeder::class,
            SenderProfileSeederTableSeeder::class,
            CustomerSeederTableSeeder::class,
        ]);
    }
}
