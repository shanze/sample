<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddMultipleColumnsToFormsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('forms', function (Blueprint $table) {
            $table->bigInteger('list_id', false, true)->nullable()->after('user_id');
            $table->json('display_settings')->nullable()->default(json_encode([
                'is_header_enabled' => 1,
                'header_text' => 'Get Free Email Update',
                'is_description_enabled' => 1,
                'description_text' => 'Join us for FREE to get instant email update',
                'is_name_label_enabled' => 1,
                'name_label_text' => 'Name',
                'is_name_label_required' => 1,
                'email_label_text' => 'Email',
                'is_phone_label_enabled' => 1,
                'phone_label_text' => 'Phone',
                'is_phone_label_required' => 1,
                'button_label_text' => 'Submit',
            ]));
            $table->json('general_settings')->nullable()->default(json_encode([
                'is_default_thank_page' => 1,
                'thank_page_url' => 'https://thankyou.com',
                'is_default_already_subscribe_page' => 1,
                'already_subscribe_page_url' => 'https://alreadysubscribe.com',
            ])); 

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('forms', function (Blueprint $table) {
            $table->dropColumn(['list_id',  'display_settings', 'general_settings']);
        });
    }
}
