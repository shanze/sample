<?php

namespace Modules\Audience\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Audience\Entities\Models\Customer;

class CustomerSeederTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        Customer::create( [
            'id'=>1,
            'user_id'=>4,
            'list_id'=>4,
            'name'=>'Hamza khan',
            'phone_no'=>NULL,
            'country'=>NULL,
            'date_of_birth'=>NULL,
            'is_email_valid'=>'1',
            'is_active'=>'1',
            'created_at'=>NULL,
            'updated_at'=>NULL
        ] );

        Customer::create( [
            'id'=>4,
            'user_id'=>4,
            'list_id'=>4,
            'name'=>'asdddddddddddddddddd',
            'phone_no'=>NULL,
            'country'=>NULL,
            'date_of_birth'=>NULL,
            'is_email_valid'=>'1',
            'is_active'=>'1',
            'created_at'=>NULL,
            'updated_at'=>NULL
        ] );

        Customer::create( [
            'id'=>5,
            'user_id'=>4,
            'list_id'=>5,
            'name'=>'asdddddddddddddddddd',
            'phone_no'=>NULL,
            'country'=>NULL,
            'date_of_birth'=>NULL,
            'is_email_valid'=>'1',
            'is_active'=>'1',
            'created_at'=>NULL,
            'updated_at'=>NULL
        ] );
    }
}
