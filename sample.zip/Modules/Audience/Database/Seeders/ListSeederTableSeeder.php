<?php

namespace Modules\Audience\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Audience\Entities\Models\Lists;

class ListSeederTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        Lists::create( [
        'id'=>4,
        'user_id'=>4,
        'title'=>'Pakistan Users',
        'description'=>'users lives in pakistan',
        'no_of_contacts'=>0,
        'is_active'=>'1',
        'created_at'=>NULL,
        'updated_at'=>NULL
    ] );



    Lists::create( [
            'id'=>5,
            'user_id'=>4,
            'title'=>'India Users',
            'description'=>'users lives in india',
            'no_of_contacts'=>0,
            'is_active'=>'1',
            'created_at'=>NULL,
            'updated_at'=>NULL
        ] );



    Lists::create( [
            'id'=>6,
            'user_id'=>4,
            'title'=>'Bangladesh users',
            'description'=>'Bangladesh users asdasd',
            'no_of_contacts'=>0,
            'is_active'=>'1',
            'created_at'=>NULL,
            'updated_at'=>NULL
        ] );
    }
}
