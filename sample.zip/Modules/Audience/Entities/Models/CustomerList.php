<?php

namespace Modules\Audience\Entities\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class CustomerList extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = ['user_id','list_id','customer_id','is_subscribed','deleted_at','is_supression','supressed_date','is_double_optin','is_subscription_confirmed','subscription_status','subscribed_at','unsubscribed_at','unsub_channel','email','customer_ip','created_at','updated_at'];


}
