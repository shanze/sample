<?php

namespace Modules\Audience\Entities\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Customer extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = ['user_id','list_id','first_name','last_name','is_email_valid','email','phone_no','country','is_supression','is_subscribed','is_double_optin',
        'is_subscription_confirmed','deleted_at','created_at','updated_at','subscribe_date','unsubscribe_date','subscription_status','supressed_date','address_one','address_two',
        'city','state','zip_code','csv_bit','is_active','unconfirmed_is_sent','csv_file_id','channel','customer_ip'];


    public function getSubscribeDateAttribute($value): string
    {
        return Carbon::parse($value)->format('m/d/y');
    }
    public function lists(): BelongsToMany
    {
        return $this->belongsToMany(Lists::class, 'customer_lists','customer_id','list_id')->where('is_subscribed',1);
    }
    public function tags(): BelongsToMany
    {
        return $this->belongsToMany(Tag::class, 'customer_tags','customer_id','tag_id')->whereNull('customer_tags.deleted_at');
    }
    public function segments(): BelongsToMany
    {
        return $this->belongsToMany(Segment::class, 'customer_segments','customer_id','segment_id')->whereNull('customer_segments.deleted_at');
    }
}
