<?php

namespace Modules\Audience\Entities;

use App\Entities\BaseEntity;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Modules\Audience\Entities\Models\Customer;
use Modules\Audience\Entities\Models\CustomerList;
use Modules\Audience\Entities\Models\Lists;
use Modules\Audience\Http\Requests\SaveListValidator;
use Throwable;

class ListEntity extends BaseEntity
{
    /**
     * @var CustomerListEntity
     */
    private $customerList;
    public function __construct(){
        $this->customerList = new CustomerListEntity();
    }
    public function getLists()
    {
        try {
            // Use eager loading with only necessary fields to optimize performance
            $list = Lists::with(['senderProfile', 'customers'])
                ->where('user_id', Auth::id())
                ->latest()
                ->take(10)
                ->get(['id', 'name', 'created_at']); // Specify fields needed to reduce data load

            return $this->helpReturn("List data", $list);
        } catch (Exception $exception) {
            return $this->helpError(1, "Something went wrong, please try again.", ["Something went wrong, please try again."]);
        }

    }
    public function getListsPaginated($request)
    {
        try {
            $searchColumns = ['lists.title'];
            $per_page = 10;
            // Build the initial query
            $query = Lists::with('senderProfile', 'customers')
                ->where('user_id', Auth::id());
            // Apply pagination and search
            paginationAndSearch($request, $per_page, $query, $searchColumns);
            // Fetch paginated results with order
            $list = $query->orderBy('id', 'desc')->paginate($per_page);
            return $this->helpReturn("List data", $list);
        } catch (Exception $exception) {
            return $this->helpError(1, "Something went wrong, please try again.", ["Something went wrong, please try again."]);
        }

    }

    public function broadcastList($contact_id){
        try {
            $userId = Auth::id();
            $listQuery = Lists::select('id', 'title')->where('user_id', $userId);

            if ($contact_id !== null) {
                $listIds = CustomerList::where('user_id', $userId)
                    ->where('customer_id', $contact_id)
                    ->where('is_subscribed', 1)
                    ->pluck('list_id');
                $listQuery->whereNotIn('id', $listIds);
            }
            $list = $listQuery->get();
            return $this->helpReturn("Customers list", $list);
        } catch (Throwable $exception) {
            Log::error('Exception in broadcastList: ' . $exception->getMessage());
            return $this->helpError(1, "Something went wrong, please try again.", ["Something went wrong, please try again."]);
        }

}



    public function saveList(Request $request)
    {
        try {
            $validator = new SaveListValidator(resolve('validator'));
            if (!$validator->with($request->all())->passes()) {
                return $this->helpError(2, "Validation Error", $validator->errors());
            }
            $userId = Auth::id();
            $request->request->add(['user_id' => $userId]);

            // Create or update list
            $list = $request->id
                ? Lists::find($request->id)->fill($request->toArray())->save()
                : Lists::create($request->toArray());

            $listId = $request->id ?: $list->id;
            if ($request->email) {
                // Add or remove contacts from list
                $request->request->add(['list_id' => $listId]);
                $customerEntity = new CustomerEntity();
                $result = $request->customer_id
                    ? $customerEntity->deleteCustomer($request->customer_id)
                    : $customerEntity->addCustomer($request);

                if ($result['_metadata']['outcomeCode'] != 200 && !isset($request->customer_id)) {
                    $customer = Customer::where('user_id', $userId)->where('email', $request->email)->first();
                    $resultNew = $this->customerList->insertCustomerList($customer, $listId);

                    if (is_array($resultNew)) {
                        return $resultNew;
                    }
                }
                // Update customers count
                self::countContactNumbers($listId);
            }
            return $this->helpReturn("List saved successfully");
        } catch (Throwable $exception) {
            return $this->helpError(1, "Something went wrong, please try again.", ["Something went wrong, please try again."]);
        }
    }
}
