<?php

namespace Modules\Audience\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Audience\Entities\ListEntity;

class ListController extends Controller
{
    /**
     * @var ListEntity
     */
    private $listEntity;

    public function __construct(){
        $this->listEntity = new ListEntity();
    }
    public function getLists(){
        return $this->listEntity->getLists();
    }
    public function getListsPaginated(Request $request){
        return $this->listEntity->getListsPaginated($request);
    }
    public function broadcastList($contact_id=null){
        return $this->listEntity->broadcastList($contact_id);
    }
    public function saveList(Request $request){
        return $this->listEntity->saveList($request);
    }
}
