<?php

namespace Modules\Audience\Http\Controllers;

use App\Traits\GlobalResponseTrait;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;
use Modules\Audience\Database\Seeders\SeedFakeCustomersTableSeeder;
use Modules\Audience\Entities\CustomerEntity;
use Modules\Payments\Entities\AMemberEntity;
use Modules\Payments\Entities\Models\Subscription;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class CustomerController extends Controller
{

    use GlobalResponseTrait;
    private $customer;

    public function __construct(){
        $this->customer = new CustomerEntity();
       // $this->responseService = new ResponseService();
    }
    public function getCustomers(Request $request){
        $customers = CustomerEntity::getCustomers($request);
        return $this->helpReturn("Customers list ", $customers);
    }

    public function getCustomersPaginated(Request $request){
        $customers = $this->customer->getCustomersPaginated($request);
        return $this->helpReturn("Customers list ", $customers);
    }
    public function getCustomerCount(Request $request){
        return $this->customer->getCustomerCount($request);
    }
    public function addCustomer(Request $request,$id = null){
        return $this->customer->addCustomer($request,$id);
    }
    public function addCustomerUsingCSV(Request $request){
        return $this->customer->addCustomerUsingCSV($request);
    }
    public function deleteCustomer($id){
        return $this->customer->deleteCustomer($id);
    }
    public function getCustomer(Request $request,$id){
        return $this->customer->getCustomer($request,$id);
    }
    public function downloadSampleFile(): BinaryFileResponse
    {
        return $this->customer->downloadSampleFile();
    }
    public function getImages(Request $request){
        return $this->customer->getImages($request);
    }
    public function unSubscribeCustomer(Request $request)
    {
        return $this->customer->unSubscribeCustomer($request);
    }
    public function subscribeCustomers(Request $request){
        return $this->customer->subscribeCustomers($request);
    }
    public function accountGrowthStats(Request $request){
        return $this->customer->accountGrowthStats($request);
    }
    public function subscribeCount(Request $request){
        return $this->customer->subscribeCount($request);
    }
    public function unsubscribeCount(Request $request){
        return $this->customer->unsubscribeCount($request);
    }
    public function emailOpenCount(Request $request){
        return $this->customer->emailOpenCount($request);
    }
    public function contactActivityStats(Request $request){
        return $this->customer->contactActivityStats($request);
    }
    public function emailClickCount(Request $request){
        return $this->customer->emailClickCount($request);
    }
    public function DailyInsightStats(Request $request){
        return $this->customer->DailyInsightStats($request);
    }
    public function contactInsightOpenClickGraph(Request $request){
        return $this->customer->contactInsightOpenClickGraph($request);
    }
    public function accountOpenClickGraph(Request $request){
        return $this->customer->accountOpenClickGraph($request);
    }
    public function AutoResponderBroadcastSentGraph(Request $request){
        return $this->customer->AutoResponderBroadcastSentGraph($request);
    }
    public function supressionContact(Request $request){
        return $this->customer->supressionContact($request);
    }
    public function supressContactList(Request $request){
        return $this->customer->supressContactList($request);
    }
    public function supressContactListPaginated(Request $request){
        return $this->customer->supressContactListPaginated($request);
    }
    public function checkSubscriptionLimit(Request $request){
        return $this->customer->checkSubscriptionLimit($request);
    }
    public function setRedisValue(Request $request){
        return $this->customer->setRedisValue($request);
    }
    public function unsubscribedCustomer($modelId){
        return $this->customer->unsubscribedCustomerViaEmail($modelId);
    }


    // Opt-in Setting module.
    public function saveOptinSetting(Request $request)
    {
        return $this->customer->saveOptinSetting($request);
    }

    public function getOptinSetting()
    {
        return $this->customer->getOptinSetting();
    }

    public function subscribeThisCustomer($id,$listId)
    {
        return $this->customer->subscribeThisCustomer($id,$listId);
    }

    public function testing($no, $listId)
    {
        $contactsSeeder = new SeedFakeCustomersTableSeeder();
        $totalContacts = $contactsSeeder->run($no, $listId);

        $userPlanInfo = isUserExceeded(Auth::user());
        if($userPlanInfo['isUserExceeded']){
            $upgradedPlan = identifyUpgradedPlan($userPlanInfo);
            $userSubscription = Subscription::where('user_id', Auth::id())->first();

             // either usage exceeded or there is no record in plans_history for this user
             if($userSubscription->marketing_plan_id != $upgradedPlan['id']){
                $userSubscription->marketing_plan_id = $upgradedPlan['id'];
                $userSubscription->subscribers = $upgradedPlan['subscribers'];
                $userSubscription->save();
                savePlanHistory($userSubscription, $upgradedPlan, $userPlanInfo['userContacts']);
                 // listener call to send email.
                // $upgradeEmailPayload = upgradeEmailPayload($upgradedPlan);
                // $listenerService = new ListenerService();
                // $listenerService->sendAutoUpgradeEmail($upgradeEmailPayload);
            }
        }

        echo '<pre>'; print_r("Total Contacts: ");
        echo '<pre>'; print_r($totalContacts);
        exit;
    }

    public function contactsCount($email=null)
    {
        // $cost=590.00;
        // $cost = ((float)$cost)/2;
        // $cost = number_format($cost,2,'.',',');
        // $cost = $cost + "0";
        // if ( !((int)($cost * 10.0) % 10 == 0) ){
        //     $cost = number_format($cost,2,'.',',');
        // }

        // $user_id = 552;

        // $discountPercentage = 0;
        // $checkDiscount = getUserDiscount($user_id,$plan);
        // if($checkDiscount['is_discount_allowed']){
        //     $discountPercentage = $checkDiscount['discount_percentage'];
        // }

        // echo '<pre>'; print_r($discountPercentage); exit;

        $amemberEntity = new AMemberEntity();
        $response = $amemberEntity->getUserAccessDetails($email);
        $response = json_decode($response,TRUE);
        if(is_null(@$response['all_data'][0]['p_id'])){
            echo '<pre>'; print_r("payment not paid"); exit;
        }
        echo '<pre>'; print_r($response);
        exit;

        // $subscription = Subscription::where('user_id', Auth::id())->first();
        // echo '<pre>userId: '; print_r(Auth::id());

        // if( $response['all_data'][0]['begin_date'] != $subscription->starts_at || $response['all_data'][0]['expire_date'] != $subscription->ends_at ){
        //     echo '<pre>'; print_r("Not Matched"); exit;
        // }else{
        //     echo '<pre>'; print_r("Matched"); exit;
        // }
        // $days = getPlanUsageCost(59, '2023-04-30 11:09:58', '2023-05-5 11:09:58');
        // echo '<pre>'; print_r($days); exit;
        // $count = Customer::where('user_id', Auth::id())->where('is_suppression', 0)->where('subscription_status', 0)->count();

        // echo '<pre>'; print_r("Total Contacts: ");
        // echo '<pre>'; print_r($count); exit;
    }

    public function ScriptRemoveAmemberUsers(Request $request)
    {
        return $this->customer->ScriptRemoveAmemberUsers($request);
    }

    public function ScriptExtendFreeTrialBPA(Request $request)
    {
        return $this->customer->ScriptExtendFreeTrialBPA($request);
    }
    public function addSsubscribersToList(Request $request)
    {
         return $this->customer->addSsubscribersToList($request);
    }
    public function getCsvFileStats(Request $request)
    {
         return $this->customer->getCsvFileStats($request);
    }
    public function getCsvFileDetails(Request $request)
    {
        return $this->customer->getCsvFileDetails($request);
    }
    public function downloadFile(Request $request): string
    {
        $file_path = '/var/www/userdata/csv-data/customer-'.$request->user_id.'/'.$request->name;
        if (file_exists($file_path)) {
            // Set headers for file download
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
            header('Content-Length: ' . filesize($file_path));

            // Read the file and output its contents
            readfile($file_path);
            exit;
        }else{
            return 'file not exit';
        }
    }
}
