<?php

namespace Modules\Audience\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Audience\Entities\SegmentEntity;

class SegmentController extends Controller
{
    /**
     * @var SegmentEntity
     */
    private $segmentEntity;

    public function __construct(){
        $this->segmentEntity = new SegmentEntity();
    }
   public function saveSegment(Request $request){
       return $this->segmentEntity->saveSegment($request);
   }
   public function getSegments(){
       return $this->segmentEntity->getSegments();
   }
   public function getSegmentsPaginated(Request $request){
       return $this->segmentEntity->getSegmentsPaginated($request);
   }
   public function getSegment(Request $request, $segmentId){
       return $this->segmentEntity->getSegment($request, $segmentId);
   }
   public function filterConditions(){
        return $this->segmentEntity->filterConditions();
   }
   public function saveSegmentFilters(Request $request){
        return $this->segmentEntity->saveSegmentFilters($request);
   }
   public function getSegmentQuery($segmentId){
       return $this->segmentEntity->getSegmentQuery($segmentId);
   }
   public function deleteSegment($segmentId){
        return $this->segmentEntity->deleteSegment($segmentId);
   }
   public function addSegmentCustomersToList(Request $request){
       return $this->segmentEntity->saveSegmentCustomersToList($request);
   }
   public function saveCustomersToSegment(Request $request){
        return $this->segmentEntity->saveCustomersToSegment($request);
   }
   public function getListSegments(){
       return $this->segmentEntity->getListSegments();
   }
}
