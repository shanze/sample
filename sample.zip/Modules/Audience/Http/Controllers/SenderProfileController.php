<?php

namespace Modules\Audience\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Audience\Entities\SenderProfileEntity;

class SenderProfileController extends Controller
{
    /**
     * @var SenderProfileEntity
     */
    private $senderEntity;

    public function __construct(){
        $this->senderEntity = new SenderProfileEntity();
    }
    public function getSenderProfiles(Request $request){
        return $this->senderEntity->getSenderProfiles($request);
    }
    public function getSenderProfilesAll(){
        return $this->senderEntity->getSenderProfilesAll();
    }
    public function saveSenderProfile(Request $request){
        return $this->senderEntity->saveSenderProfile($request);
    }
    public function getSenderProfile($id){
        return $this->senderEntity->getSenderProfile($id);
    }
    public function setDefaultSenderProfile(Request $request){
        return $this->senderEntity->setDefaultSenderProfile($request->id);
    }
    public function editSenderProfile(Request $request, $id)
    {
        return $this->senderEntity->editSenderProfile($request, $id);
    }
    public function deleteSenderProfile($id)
    {
        return $this->senderEntity->deleteSenderProfile($id);
    }
    public function getEmailFooter($id)
    {
        return $this->senderEntity->getEmailFooter($id);
    }
}
