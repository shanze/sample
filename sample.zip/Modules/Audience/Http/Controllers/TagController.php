<?php

namespace Modules\Audience\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Audience\Entities\TagEntity;

class TagController extends Controller
{
    /**
     * @var TagEntity
     */
    private $tagEntity;

    public function __construct(){
        $this->tagEntity = new TagEntity();
    }
    public function saveTag(Request $request){
        return $this->tagEntity->saveTag($request);
    }
    public function tagsList(Request $request){
        return $this->tagEntity->tagsList($request);
    }
    public function deleteTag($tagId){
        return $this->tagEntity->deleteTag($tagId);
    }
    public function tagDetails($tagId,Request $request){
        return $this->tagEntity->tagDetails($tagId,$request);
    }
    public function getListTags(){
        return $this->tagEntity->getListTags();
    }
    public function addTagToCustomer(Request $request){
        return $this->tagEntity->addTagToCustomer($request);
    }
    public function removeTagToCustomer(Request $request){
        return $this->tagEntity->removeTagToCustomer($request);
    }
}
