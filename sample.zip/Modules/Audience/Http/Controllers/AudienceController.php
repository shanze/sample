<?php

namespace Modules\Audience\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Modules\Audience\Entities\Models\ReleaseNotes;
use App\Traits\GlobalResponseTrait;

class AudienceController extends Controller
{
    use GlobalResponseTrait;
    public function getStatus(Request $request){
        $notes =  ReleaseNotes::select('user_id','status')->where('user_id',Auth::id())->first();
        if($notes != null) {
            return $this->helpReturn("Release status", $notes->toArray());
        }
    }
    public function updateStatus(Request $request){
        ReleaseNotes::where('user_id',Auth::id())->update(['status' => 0]);
        return $this->helpReturn("Release status updated");
    }


}
