<?php

namespace Modules\Audience\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Audience\Entities\WebhookEntity;

class WebhookController extends Controller
{
    private $webhookEntity;
    public function __construct()
    {
        $this->webhookEntity = new WebhookEntity();
    }
    
    public function webhooks(Request $request)
    {
        return $this->webhookEntity->webhooks($request);
    }

    public function saveWebhook(Request $request)
    {
        return $this->webhookEntity->saveWebhook($request);
    }

    public function generateWebhookUrl()
    {
        return $this->webhookEntity->generateWebhookUrl();
    }

    public function subscribeViaWebhook(Request $request, $list)
    {
        return $this->webhookEntity->subscribeViaWebhook($request, $list);
    }
}
