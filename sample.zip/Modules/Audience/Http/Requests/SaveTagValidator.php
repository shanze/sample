<?php

namespace Modules\Audience\Http\Requests;

use App\Services\Validations\LaravelValidator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class SaveTagValidator extends LaravelValidator
{
    protected $rules;

    protected $messages;

    public function passes(): bool
    {
        $this->messages = [
            'name.required' => 'Tag name is required',
            'name.unique' => 'Tag name already exists'
        ];

        $tagId = $this->data['id'] ?? null;
        $query =  Rule::unique('tags','name')->where('user_id',Auth::id())->whereNull('deleted_at');
        if ($tagId)
            $query->ignore($tagId);

        $this->rules = [
            //'name' => 'required|unique:tags,name,' .$tagId,
            'name' => [
                'required',
                $query
            ],
            'id'  => 'nullable|exists:tags'
        ];

        return parent::passes();
    }
}
