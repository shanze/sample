<?php

namespace Modules\Audience\Http\Requests;

use App\Services\Validations\LaravelValidator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class SaveListValidator extends LaravelValidator
{
    protected $rules;

    protected $messages;

    public function passes(): bool
    {
        //$userId = $this->data['user_id'];
        $this->messages = [
            'title.required' => 'List name is required',
            'title.unique' => 'List name already exists'
        ];

        $listId = $this->data['id'] ?? null;
        $query =  Rule::unique('lists','title')->where('user_id',Auth::id())->whereNull('deleted_at');
        if ($listId)
            $query->ignore($listId);

        $this->rules = [
            //'title' => 'required|unique:lists,title,' .$listId,
            'title' => [
              'required',
              $query,
            ],
            'sender_profile_id' => 'nullable|exists:sender_profiles,id',
            'id'  => 'nullable|exists:lists'
        ];

        return parent::passes();
    }
}
