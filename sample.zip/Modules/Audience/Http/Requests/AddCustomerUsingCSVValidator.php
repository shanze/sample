<?php

namespace Modules\Audience\Http\Requests;

use App\Services\Validations\LaravelValidator;

class AddCustomerUsingCSVValidator extends LaravelValidator
{
    protected $rules;

    protected $messages;

    public function passes()
    {
        $this->messages = [
            'list_id.required' => 'The List field is required',
            'list_id.exists' => 'The List field is not valid',
        ];

        $this->rules = [
            'list_id' => 'required|exists:lists,id',
            'file' => [
                'required',
                'mimes:csv,txt',
            ]
        ];

        return parent::passes();
    }
}
