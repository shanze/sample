<?php

namespace Modules\Audience\Http\Requests;

use App\Services\Validations\LaravelValidator;
use Illuminate\Validation\Rule;

class SaveContactRequestValidator extends LaravelValidator
{

    protected $rules;

    protected $messages;

    public function passes()
    {
        $userId = $this->data['user_id'];
        $this->messages = [
            'email.required' => 'The email field is required',
            'list_id.required' => 'The List field is required',
            //'email.unique' => 'This email address already exists',
        ];

        $this->rules = [
           // 'email' => 'required|unique:customers,user_id',
            'list_id' => 'required',
            'email' => [
                'required',
                'email',
               // Rule::unique('customers')->where('user_id', $userId)->whereNull('deleted_at'),
            ]
        ];

        return parent::passes();
    }
}
