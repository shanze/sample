<?php

namespace Modules\Audience\Http\Requests;

use App\Services\Validations\LaravelValidator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class SaveSegmentValidator extends LaravelValidator
{
    protected $rules;

    protected $messages;

    public function passes(): bool
    {
        //$userId = $this->data['user_id'];
        $this->messages = [
            'name.required' => 'Segment name is required',
            'name.unique' => 'Segment name already exists'
        ];

        $segmentId = $this->data['id'] ?? null;
        $query =  Rule::unique('segments','name')->where('user_id',Auth::id())->whereNull('deleted_at');
        if ($segmentId)
            $query->ignore($segmentId);

        $this->rules = [
            //'title' => 'required|unique:lists,title,' .$listId,
            'name' => [
                'required',
                $query
            ],
            'id'  => 'nullable|exists:segments'
        ];

        return parent::passes();
    }
}
