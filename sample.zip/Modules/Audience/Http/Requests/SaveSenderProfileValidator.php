<?php

namespace Modules\Audience\Http\Requests;

use App\Services\Validations\LaravelValidator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class SaveSenderProfileValidator extends LaravelValidator
{
    protected $rules;
    protected $messages;

    public function passes(): bool
    {
        //$userId = $this->data['user_id'];
        $this->messages = [
            'sender_name.required' => 'Sender name is required',
            'sender_domain_id'  => "Sender domain is required",
            // 'from_name' => 'From name is required'
            //'title.unique' => 'List name already exists'
        ];

//        $senderId = $this->data['id'] ?? null;
//        $query =  Rule::unique('lists','title')->where('user_id',Auth::id())->whereNull('deleted_at');
//        if ($senderId)
//            $query->ignore($senderId);

        $this->rules = [
            'sender_name' => 'required',
            'sender_domain_id' => 'required',
            'company_name' => 'required',
            'from_email' => 'required|email',
            'reply_to_email' => 'required|email',
            'street' => 'required',
            'city' => 'required',
            'state' => 'required',
            'zip'  => 'required',
            'country' => 'required'
//            'title' => [
//                'required',
//                $query,
//            ],
           // 'sender_profile_id' => 'nullable|exists:sender_profiles,id',
           // 'id'  => 'nullable|exists:lists'
        ];

        return parent::passes();
    }

}
