<?php

namespace Modules\Audience\Http\Requests;

use App\Services\Validations\LaravelValidator;
use Illuminate\Validation\Rule;

class SaveWebhookContactRequestValidator extends LaravelValidator
{

    protected $rules;

    protected $messages;

    public function passes()
    {
        $this->messages = [
            'email.required' => 'The email field is required',
            'list_id.required' => 'The List field is required',
            'api_hash.required' => 'The Hash field is required',
            'api_key.required' => 'The Key field is required',
        ];

        $this->rules = [
            'list_id' => 'required',
            'api_hash' => 'required',
            'api_key' => 'required',
            'email' => [
                'required',
                'email',
            ]
        ];

        return parent::passes();
    }
}
