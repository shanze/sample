<?php

namespace Modules\Audience\Http\Requests;

use App\Services\Validations\LaravelValidator;

class OptinSettingValidation extends LaravelValidator
{

    protected $rules;

    protected $messages;

    public function passes()
    {
        $this->messages = [
            'optin_setting.required' => 'Choose optin setting',
        ];

        $this->rules = [
            'optin_setting' => 'required',
        ];

        return parent::passes();
    }
}
